from datetime import datetime  # noqa: F401

import datazimmer as dz


class DogPair(dz.BaseEntity):
    pass
